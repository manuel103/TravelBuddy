package com.example.travelbuddy;

public class ScreenItem {
}
