package com.example.travelbuddy;

public class Login {
}
