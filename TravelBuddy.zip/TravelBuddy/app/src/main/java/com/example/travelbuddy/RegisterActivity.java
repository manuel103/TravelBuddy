package com.example.travelbuddy;

public class RegisterActivity {
}
